# 📋 PLANO DE IMPLEMENTAÇÃO - Melhorias Críticas

**Data:** Fevereiro 2026  
**Alvo:** Elevar roadmap de 4.25/5 para 4.8+/5  
**Timeline:** 4-5 semanas (part-time)  
**Esforço Total:** 70-80 horas

---

## 🎯 ONDA 1: Quick Wins (Semana 1) - 12 horas

### Task 1.1: Criar LEARNING-PATHS.md (4 horas)

**Arquivo novo:** `LEARNING-PATHS.md`

```markdown
# 🗺️ Learning Paths Alternativos - Navegação Orientada a Objetivos

## Por Que Múltiplos Caminhos?

Cada desenvolvedor tem diferentes objetivos:
- Alguns querem ser especialistas em APIs (tipo seu trabalho em Greenn)
- Outros querem dominar admin (tipo clientes tradicionais)
- Outros querem ser headless specialists (tipo PEBMED)

## Path 1: "Backend APIs Specialist" (Seu Caminho)

**Duração:** 8-10 semanas  
**Objetivo:** Dominar REST APIs, Async Jobs, DevOps

**Sequência:**
1. Fase 1 - WordPress Core (complete)
2. Fase 2 - REST API Fundamentals (complete)
3. Fase 3 - REST API Advanced (complete)
4. **[SECURITY ESSENTIALS]** - 2-3 horas
5. **[TESTING THROUGHOUT]** - Focar em API tests
6. Fase 7 - WP-CLI Fundamentals (skip Fase 4,5,6)
7. Fase 9 - WP-CLI Ferramentas (skip Fase 8 - menos relevante)
8. Fase 13 - Arquitetura Avançada (DDD, Service Layer)
9. Fase 15 - Async Jobs & Background Processing (critical)
10. Fase 14 - Deployment & DevOps (complete)

**Documentos a SKIP:**
- Fase 4: Settings API (não relevante)
- Fase 5: CPT (não relevante para APIs)
- Fase 6: Shortcodes (não relevante)
- Fase 8: Performance (pode fazer depois)
- Fase 11: Multisite (avançado)

**Por quê:** APIs geralmente não precisam de admin pages, CPT, ou multisite

**Tempo Total:** 8-10 semanas (vs 15+ para tudo)

---

## Path 2: "Full Stack Admin Developer"

**Duração:** 12-14 semanas  
**Objetivo:** Criar plugins admin-centric, customizações completas

**Sequência:**
1. Fase 1 - WordPress Core (complete)
2. Fase 2 - REST API Fundamentals (basics only)
3. **[SECURITY ESSENTIALS]**
4. **[TESTING THROUGHOUT]**
5. Fase 4 - Settings API & Admin (complete)
6. Fase 5 - Custom Post Types (complete)
7. Fase 6 - Shortcodes, Widgets, Gutenberg (complete)
8. Fase 8 - Performance & Cache (important for frontend)
9. Fase 12 - Security (complete)
10. Fase 13 - Architecture (optional, depends on project size)
11. Fase 14 - Deployment (complete)

**Documentos a SKIP:**
- Fase 3: REST API Advanced (não necessário)
- Fase 7: WP-CLI (nice-to-have)
- Fase 9: WP-CLI Ferramentas (nice-to-have)
- Fase 15: Async Jobs (nice-to-have, simpler projects)
- Fase 11: Multisite (avançado)

**Por quê:** Admin-focused plugins não precisam de advanced APIs ou async jobs

---

## Path 3: "Enterprise Headless CMS"

**Duração:** 14-16 semanas  
**Objetivo:** REST API headless, decoupled frontend, React/Vue

**Sequência:**
1. Fase 1 - WordPress Core (essentials only)
2. Fase 2 - REST API Fundamentals (complete)
3. Fase 3 - REST API Advanced (complete)
4. **[SECURITY ESSENTIALS]** (critical)
5. **[TESTING THROUGHOUT]** (critical)
6. Fase 5 - Custom Post Types (for content modeling)
7. Fase 13 - Architecture (DDD, DI, critical)
8. Fase 15 - Async Jobs (critical for webhooks)
9. Fase 14 - Deployment & DevOps (complete)
10. Fase 8 - Performance (for API performance)
11. [Advanced Topics] - GraphQL (optional)

**Documentos a SKIP:**
- Fase 4: Settings API (WordPress admin not used)
- Fase 6: Shortcodes (not relevant for headless)
- Fase 7: WP-CLI (automation only)
- Fase 11: Multisite (maybe advanced)
- Fase 12: Security Basic (covered in early phases)

**Por quê:** Headless CMS focuses entirely on APIs, no admin interface

---

## Path 4: "Performance Architect"

**Duração:** 10-12 semanas  
**Objetivo:** Otimizar performance, cache, CDN, infrastructure

**Sequência:**
1. Fase 1 - WordPress Core (complete)
2. Fase 2 - REST API Fundamentals (basics)
3. **[TESTING THROUGHOUT]** (performance testing)
4. Fase 8 - Performance & Cache (complete + expand)
5. **[CACHE INVALIDATION PATTERNS]** (critical)
6. Fase 14 - Deployment & DevOps (infrastructure focus)
7. Fase 13 - Architecture (scalability patterns)
8. Fase 15 - Async Jobs (performance impact)
9. [Advanced Topics] - CDN, Database Optimization

**Documentos a SKIP:**
- Fases 4,5,6: Admin features (não relevante)
- Fase 7: WP-CLI (menos relevante)
- Fase 11: Multisite (avançado)
- Fase 12: Security (basics only)

**Por quê:** Performance requires deep understanding of PHP, Database, Infrastructure

---

## Dependency Matrix

```
┌─────────────────────────────────────────┐
│ TODAS OS CAMINHOS COMEÇAM COM:         │
│ ✅ Fase 1: Core (obrigatório)          │
│ ✅ Security Essentials (obrigatório)   │
│ ✅ Testing Throughout (recomendado)    │
└─────────────────────────────────────────┘

Path 1 (APIs):
1 → [Security] → [Testing] → 2 → 3 → 7 → 9 → 13 → 15 → 14

Path 2 (Admin):
1 → [Security] → [Testing] → 4 → 5 → 6 → 8 → 12 → 14

Path 3 (Headless):
1 → [Security] → [Testing] → 2 → 3 → 5 → 13 → 15 → 14 → 8

Path 4 (Performance):
1 → [Security] → [Testing] → 8 → [Cache Patterns] → 14 → 13 → 15
```

---

## Como Usar Este Documento

**Se você é iniciante:**
"Qual é meu objetivo?" → Escolha path → Siga sequência

**Se você é experiente:**
"Já tenho base em X" → Pule fases que já domina → Continue

**Para comunidade:**
Compartilhe qual path você seguiu e quanto tempo levou

---

**Adicionado ao:** ÍNDICE  
**Referenciado de:** Início de cada Fase  
**Próxima revisão:** Q2 2026
```

**Conteúdo Total:** 400-500 linhas  
**Arquivo:** LEARNING-PATHS.md

---

### Task 1.2: Adicionar Security Essentials a Fase 2 (4 horas)

**Localização:** Fase 2 - `002-WordPress-Fase-2-...md`  
**Nova Seção:** Após 2.8 (REST Response), antes de 2.9 (Documentação)

```markdown
## 2.9 Security Essentials for REST APIs

### 2.9.1 Input Validation (Essential)

Problem: User input is ALWAYS untrusted

✅ DO THIS:

add_action('rest_api_init', function() {
    register_rest_route('myapp/v1', '/users', [
        'methods' => 'POST',
        'callback' => 'create_user',
        'args' => [
            'email' => [
                'required' => true,
                'type' => 'string',
                'validate_callback' => function($param) {
                    return is_email($param) || new WP_Error(
                        'invalid_email',
                        'Email must be valid'
                    );
                }
            ],
            'name' => [
                'required' => true,
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field'
            ]
        ]
    ]);
});

❌ DON'T DO THIS:

register_rest_route('myapp/v1', '/users', [
    'callback' => function($request) {
        $email = $request->get_param('email');
        // Trust the email? DANGER!
    }
]);
```

### 2.9.2 Output Escaping (Essential)

Problem: Output is also untrusted

✅ DO THIS:

function get_user($request) {
    $user = get_user_by('email', $request->get_param('email'));
    
    return [
        'email' => esc_html($user->user_email),
        'name' => esc_html($user->user_login)
    ];
}

❌ DON'T DO THIS:

function get_user($request) {
    $user = get_user_by('email', $request->get_param('email'));
    
    return [
        'email' => $user->user_email,      // Raw output!
        'name' => $user->user_login        // Possible XSS!
    ];
}

### 2.9.3 Nonces in REST (Essential)

Problem: CSRF protection needed

✅ DO THIS:

// In frontend
<button onclick="updateData()">Update</button>

<script>
async function updateData() {
    const response = await fetch('/wp-json/myapp/v1/update', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': document.querySelector('meta[name="wp-nonce"]').content
        },
        body: JSON.stringify({...})
    });
}
</script>

// In PHP endpoint
add_action('rest_api_init', function() {
    register_rest_route('myapp/v1', '/update', [
        'methods' => 'POST',
        'callback' => 'handle_update',
        'permission_callback' => function($request) {
            $nonce = $request->get_header('X-WP-Nonce');
            return wp_verify_nonce($nonce, 'wp_rest') !== false;
        }
    ]);
});

❌ DON'T DO THIS:

// No nonce verification!
register_rest_route('myapp/v1', '/update', [
    'callback' => 'handle_update'
]);

### 2.9.4 Capability Checks (Essential)

Problem: Not all users should access all endpoints

✅ DO THIS:

register_rest_route('myapp/v1', '/delete-user/(?P<id>\d+)', [
    'methods' => 'DELETE',
    'callback' => 'delete_user_endpoint',
    'permission_callback' => function() {
        return current_user_can('delete_users');
    }
]);

❌ DON'T DO THIS:

register_rest_route('myapp/v1', '/delete-user/(?P<id>\d+)', [
    'callback' => 'delete_user_endpoint'
    // Anyone can delete anyone!
]);

### 2.9.5 Common Mistakes Checklist

Before deploying REST API:

- [ ] All inputs validated with validate_callback
- [ ] All outputs escaped with esc_html, esc_url, esc_attr
- [ ] Nonces required for POST/PUT/DELETE
- [ ] permission_callback on every endpoint
- [ ] SQL queries use $wpdb->prepare()
- [ ] No direct $_GET, $_POST, $_REQUEST usage
- [ ] Error messages don't leak sensitive info
- [ ] Rate limiting implemented (optional but recommended)
- [ ] HTTPS required in production
- [ ] CORS properly configured

---
```

**Conteúdo:** 300-350 linhas  
**Posição:** Seção 2.9 em Fase 2

---

### Task 1.3: Expandir Fase 8 - Cache Invalidation (4 horas)

**Localização:** Fase 8 - `008-WordPress-...Performance-Cache.md`  
**Nova Seção:** Após cache setup, antes de conclusão

```markdown
## 8.4 Cache Invalidation Patterns (CRITICAL)

### Problem: Learning to Cache is Easy, Invalidating is Hard

❌ Desenvolvedor aprender a cachear:
wp_cache_set('expensive', $data, '', 3600);

✅ Mas NUNCA aprende a INVALIDAR quando dados mudam!

Resultado: Dados stale em produção, cache nunca atualizado

### 8.4.1 Cache Key Versioning

Problem: How to invalidate nested caches?

✅ DO THIS:

class PostCacheManager {
    private function getVersionKey(int $post_id): string {
        // Incrementar esta chave invalida todas as caches relacionadas
        return wp_cache_get("post_{$post_id}_version") ?? 1;
    }
    
    private function getCacheKey(int $post_id): string {
        $version = $this->getVersionKey($post_id);
        return "post_{$post_id}_v{$version}";
    }
    
    public function getPost(int $post_id) {
        $key = $this->getCacheKey($post_id);
        
        $data = wp_cache_get($key);
        if (false === $data) {
            $data = $this->fetchFromDB($post_id);
            wp_cache_set($key, $data, '', 3600);
        }
        
        return $data;
    }
    
    public function invalidatePost(int $post_id) {
        // Incrementar version invalida automaticamente TODAS as chaves
        $current = wp_cache_get("post_{$post_id}_version") ?? 1;
        wp_cache_set("post_{$post_id}_version", $current + 1);
    }
}

❌ DON'T DO THIS:

// Hardcoded keys, muito difícil de invalidar
wp_cache_set('post_123_title', $title);
wp_cache_set('post_123_content', $content);
wp_cache_set('post_123_meta', $meta);

// Se uma muda, qual cache invalidar?
// Se esquecer um, dados fica stale

### 8.4.2 Cascade Invalidation

Problem: Post A depends on Post B, which depends on Post C

✅ DO THIS:

class PostDependencyManager {
    private array $dependencies = [];
    
    public function addDependency(int $post_id, int $depends_on_id) {
        if (!isset($this->dependencies[$depends_on_id])) {
            $this->dependencies[$depends_on_id] = [];
        }
        $this->dependencies[$depends_on_id][] = $post_id;
    }
    
    public function invalidateWithCascade(int $post_id) {
        // Invalidar this post
        $this->invalidatePost($post_id);
        
        // Invalidar todos que dependem dela
        if (isset($this->dependencies[$post_id])) {
            foreach ($this->dependencies[$post_id] as $dependent_id) {
                // Recursive invalidation
                $this->invalidateWithCascade($dependent_id);
            }
        }
    }
}

// Uso
add_action('save_post', function($post_id) {
    $manager = new PostDependencyManager();
    $manager->addDependency(456, 123); // Post 456 depends on Post 123
    
    // Ao salvar Post 123, invalida 456 também
    $manager->invalidateWithCascade($post_id);
});

### 8.4.3 Cache Stampede Prevention

Problem: 1000 requests hit at cache expiry simultaneously

✅ DO THIS:

class CacheStampedeProtection {
    private const LOCK_TTL = 10; // seconds
    
    public function getWithProtection(
        string $key,
        callable $callback,
        int $ttl = 3600
    ) {
        $data = wp_cache_get($key);
        
        if (false !== $data) {
            return $data;
        }
        
        // Try to acquire lock
        $lock_key = "{$key}_lock";
        $lock_acquired = wp_cache_add(
            $lock_key,
            '1',
            '',
            self::LOCK_TTL
        );
        
        if (!$lock_acquired) {
            // Lock exists, wait for result
            // Return stale data in meantime
            $stale = wp_cache_get("{$key}_stale");
            return $stale ?: $callback();
        }
        
        // Got the lock, compute the value
        try {
            $data = $callback();
            
            // Save fresh data
            wp_cache_set($key, $data, '', $ttl);
            
            // Keep stale version for stampede protection
            wp_cache_set("{$key}_stale", $data, '', $ttl * 2);
            
            return $data;
        } finally {
            // Release lock
            wp_cache_delete($lock_key);
        }
    }
}

// Uso
$cache = new CacheStampedeProtection();
$posts = $cache->getWithProtection(
    'all_posts',
    fn() => get_posts(['numberposts' => -1]),
    3600
);

### 8.4.4 Stale-While-Revalidate Pattern

Problem: Always re-computing is expensive, stale data is acceptable

✅ DO THIS:

class StaleWhileRevalidate {
    public function get(
        string $key,
        callable $callback,
        int $fresh_ttl = 300,      // 5 min fresh
        int $stale_ttl = 3600      // 1 hour stale
    ) {
        $fresh = wp_cache_get($key);
        if (false !== $fresh) {
            return $fresh; // Serve fresh
        }
        
        $stale = wp_cache_get("{$key}_stale");
        
        // Recompute in background if needed
        as_enqueue_async_action('recompute_cache', [
            $key,
            $callback,
            $fresh_ttl,
            $stale_ttl
        ]);
        
        if (false !== $stale) {
            return $stale; // Serve stale while recomputing
        }
        
        // No cache at all, compute now
        return $callback();
    }
}

// Uso: Always fast response
$data = new StaleWhileRevalidate();
$posts = $data->get(
    'homepage_posts',
    fn() => get_posts(['post_type' => 'post', 'numberposts' => 10]),
    fresh_ttl: 300,
    stale_ttl: 3600
);

### 8.4.5 Cache Warming

Problem: Cache is empty at startup, first requests are slow

✅ DO THIS:

class CacheWarmer {
    public function warmCriticalPaths() {
        // Run on deployment
        
        // Warm popular posts
        $popular = get_posts([
            'meta_key' => '_view_count',
            'orderby' => 'meta_value_num',
            'order' => 'DESC',
            'numberposts' => 20
        ]);
        
        foreach ($popular as $post) {
            wp_cache_set(
                "post_{$post->ID}",
                $this->getPostData($post->ID),
                '',
                3600
            );
        }
        
        // Warm settings
        wp_cache_set(
            'all_settings',
            $this->getAllSettings(),
            '',
            3600
        );
    }
}

// Run during deployment
add_action('wp_loaded', function() {
    if (wp_is_development_environment()) return;
    
    if (!wp_cache_get('_warmed')) {
        $warmer = new CacheWarmer();
        $warmer->warmCriticalPaths();
        wp_cache_set('_warmed', true, '', DAY_IN_SECONDS);
    }
});
```

**Conteúdo:** 400+ linhas  
**Posição:** Seção 8.4 em Fase 8

---

## 🎯 ONDA 2: Critical Core (Semana 2-3) - 40 horas

### Task 2.1: Expandir Testing Throughout Document (25 horas)

**Arquivo existente:** `017-WordPress-Testing-Throughout.md`  
**Ação:** EXPANDIR significativamente

Adicionar para CADA uma dessas seções exemplos de teste:

```markdown
# Testing Throughout - Exemplos Práticos em PHPUnit

## Fase 1: Testing Hook System

### 1.1 Testing Actions

✅ Test that action fires:

class ActionSystemTest extends WP_UnitTestCase {
    public function test_action_fires() {
        $this->assertTrue(false);
        
        add_action('my_custom_action', function() use (&$fired) {
            $this->assertTrue(true);
        });
        
        do_action('my_custom_action');
    }
    
    public function test_action_priority() {
        $results = [];
        
        add_action('my_action', fn() => $results[] = 1, 10);
        add_action('my_action', fn() => $results[] = 2, 5);
        add_action('my_action', fn() => $results[] = 3, 15);
        
        do_action('my_action');
        
        // Lower priority runs first
        $this->assertEquals([2, 1, 3], $results);
    }
}

### 1.2 Testing Filters

✅ Test filter modification:

class FilterSystemTest extends WP_UnitTestCase {
    public function test_filter_modifies_content() {
        add_filter('the_content', fn($c) => 'Filtered: ' . $c);
        
        $result = apply_filters('the_content', 'Original');
        
        $this->assertEquals('Filtered: Original', $result);
    }
    
    public function test_filter_chain() {
        add_filter('value', fn($v) => $v . '1');
        add_filter('value', fn($v) => $v . '2');
        add_filter('value', fn($v) => $v . '3');
        
        $result = apply_filters('value', '');
        
        $this->assertEquals('123', $result);
    }
}

## Fase 2: Testing REST API

### 2.1 Testing Controllers

✅ Test endpoint returns correct data:

class PostsRestTest extends WP_REST_TestCase {
    public function setUp(): void {
        parent::setUp();
        $this->user = $this->factory->user->create(['role' => 'editor']);
    }
    
    public function test_get_posts_endpoint() {
        $post = $this->factory->post->create(['post_author' => $this->user]);
        
        $request = new WP_REST_Request('GET', '/wp/v2/posts');
        $response = rest_get_server()->dispatch($request);
        
        $this->assertEquals(200, $response->get_status());
        $this->assertCount(1, $response->get_data());
    }
    
    public function test_requires_authentication() {
        $request = new WP_REST_Request('POST', '/wp/v2/posts');
        $response = rest_get_server()->dispatch($request);
        
        $this->assertEquals(401, $response->get_status());
    }
}

### 2.2 Testing Validation

✅ Test input validation:

class RestValidationTest extends WP_REST_TestCase {
    public function test_invalid_email_rejected() {
        $request = new WP_REST_Request('POST', '/myapp/v1/users');
        $request->set_json_params([
            'email' => 'not-an-email',
            'name' => 'John'
        ]);
        
        $response = rest_get_server()->dispatch($request);
        
        // Should fail validation
        $this->assertTrue($response->is_error() || 400 === $response->get_status());
    }
}

## Fase 4: Testing Settings API

### 4.1 Testing Sanitization

✅ Test settings sanitization:

class SettingsSanitizationTest extends WP_UnitTestCase {
    public function test_number_setting_validated() {
        // Register setting with custom sanitization
        register_setting('mygroup', 'my_number', [
            'sanitize_callback' => function($value) {
                if (!is_numeric($value)) {
                    return get_option('my_number');
                }
                return intval($value);
            }
        ]);
        
        // Try to save invalid data
        update_option('my_number', 'not-a-number');
        
        // Should remain unchanged
        $this->assertNotEquals('not-a-number', get_option('my_number'));
    }
}

## Fase 5: Testing CPT & Taxonomies

### 5.1 Testing CPT Registration

✅ Test CPT exists and correct:

class CPTRegistrationTest extends WP_UnitTestCase {
    public function test_cpt_exists() {
        $this->assertTrue(post_type_exists('my_cpt'));
    }
    
    public function test_cpt_has_correct_supports() {
        $post_type = get_post_type_object('my_cpt');
        
        $this->assertTrue(post_type_supports('my_cpt', 'title'));
        $this->assertTrue(post_type_supports('my_cpt', 'editor'));
    }
}

### 5.2 Testing Taxonomy Assignment

✅ Test taxonomy relationships:

class TaxonomyTest extends WP_UnitTestCase {
    public function test_assign_taxonomy_to_post() {
        $post_id = $this->factory->post->create(['post_type' => 'my_cpt']);
        $term_id = $this->factory->term->create(['taxonomy' => 'my_taxonomy']);
        
        wp_set_post_terms($post_id, $term_id, 'my_taxonomy');
        
        $terms = wp_get_post_terms($post_id, 'my_taxonomy');
        
        $this->assertCount(1, $terms);
        $this->assertEquals($term_id, $terms[0]->term_id);
    }
}

## Fase 13: Testing Architecture Patterns

### 13.1 Testing Service Layer

✅ Test business logic:

class UserRegistrationServiceTest extends WP_UnitTestCase {
    public function test_registration_creates_user() {
        $service = new UserRegistrationService(
            new UserValidator(),
            new UserRepository(),
            $this->createMock(EmailService::class),
            $this->createMock(Logger::class)
        );
        
        $user_id = $service->register([
            'email' => 'test@example.com',
            'password' => 'SecurePassword123!',
            'name' => 'Test User'
        ]);
        
        $this->assertIsInt($user_id);
        $user = get_user_by('id', $user_id);
        $this->assertEquals('test@example.com', $user->user_email);
    }
}

### 13.2 Testing Repository Pattern

✅ Test data access:

class UserRepositoryTest extends WP_UnitTestCase {
    public function test_find_by_email() {
        $email = 'test@example.com';
        $user_id = $this->factory->user->create(['user_email' => $email]);
        
        $repo = new UserRepository();
        $user = $repo->findByEmail($email);
        
        $this->assertEquals($user_id, $user->ID);
    }
}

## Fase 15: Testing Async Jobs

### 15.1 Testing Action Scheduler

✅ Test async actions:

class AsyncJobTest extends WP_UnitTestCase {
    public function test_action_enqueued() {
        $job_id = as_enqueue_async_action('my_job', ['data' => 123]);
        
        $this->assertIsInt($job_id);
        $this->assertTrue(as_has_scheduled_action('my_job'));
    }
    
    public function test_action_executes() {
        $executed = false;
        
        add_action('my_test_job', function() use (&$executed) {
            $executed = true;
        });
        
        as_enqueue_async_action('my_test_job');
        
        // Manually trigger for testing
        do_action('my_test_job');
        
        $this->assertTrue($executed);
    }
}
```

**Conteúdo Total:** 1,500+ linhas  
**Arquivo:** Expandir 017-WordPress-Testing-Throughout.md

---

### Task 2.2: Security Anti-patterns Document (15 horas)

**Arquivo novo:** `019-WordPress-Security-Anti-patterns.md`

```markdown
# 🔒 Security Anti-patterns - O Que Não Fazer em Cada Fase

## Fase 1: Core Hooks - Common Security Mistakes

### ❌ Anti-pattern 1.1: Output User Input Directly

```php
// ❌ WRONG
add_filter('the_content', function($content) {
    return $content . $_GET['message'];
    // Possible Stored/Reflected XSS
});

// ✅ RIGHT
add_filter('the_content', function($content) {
    $message = isset($_GET['message']) 
        ? sanitize_text_field($_GET['message'])
        : '';
    return $content . esc_html($message);
});
```

### ❌ Anti-pattern 1.2: Direct SQL Queries

```php
// ❌ WRONG
add_action('wp_loaded', function() {
    global $wpdb;
    $results = $wpdb->get_results(
        "SELECT * FROM {$wpdb->posts} WHERE ID = " . $_GET['post_id']
    );
    // SQL Injection vulnerability
});

// ✅ RIGHT
add_action('wp_loaded', function() {
    global $wpdb;
    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->posts} WHERE ID = %d",
        $_GET['post_id']
    ));
});
```

## Fase 2: REST API - Common Security Mistakes

### ❌ Anti-pattern 2.1: No Input Validation

```php
// ❌ WRONG
add_action('rest_api_init', function() {
    register_rest_route('myapp/v1', '/users', [
        'callback' => function($request) {
            $email = $request->get_param('email');
            // What if email is not actually an email?
            wp_create_user($email, 'password');
        }
    ]);
});

// ✅ RIGHT
add_action('rest_api_init', function() {
    register_rest_route('myapp/v1', '/users', [
        'args' => [
            'email' => [
                'required' => true,
                'validate_callback' => 'is_email'
            ]
        ],
        'callback' => function($request) {
            // Email is guaranteed valid now
            wp_create_user($request->get_param('email'), 'password');
        }
    ]);
});
```

### ❌ Anti-pattern 2.2: No Permission Checks

```php
// ❌ WRONG
register_rest_route('myapp/v1', '/admin/settings', [
    'methods' => 'POST',
    'callback' => 'update_admin_settings'
    // Anyone can access!
]);

// ✅ RIGHT
register_rest_route('myapp/v1', '/admin/settings', [
    'methods' => 'POST',
    'callback' => 'update_admin_settings',
    'permission_callback' => function() {
        return current_user_can('manage_options');
    }
]);
```

## Fase 4: Settings API - Common Mistakes

### ❌ Anti-pattern 4.1: No Validation

```php
// ❌ WRONG
register_setting('mygroup', 'api_key');
// No sanitization, no validation!

// ✅ RIGHT
register_setting('mygroup', 'api_key', [
    'type' => 'string',
    'sanitize_callback' => function($value) {
        // Validate format
        if (!preg_match('/^[a-z0-9]{32}$/', $value)) {
            add_settings_error('mygroup', 'invalid_key', 'Invalid API key format');
            return get_option('api_key'); // Revert
        }
        return sanitize_text_field($value);
    }
]);
```

## Full Security Checklist by Phase

[Este documento continuaria com mais 500+ linhas de anti-patterns reais]
```

**Conteúdo:** 400-500 linhas  
**Arquivo:** NOVO - `019-WordPress-Security-Anti-patterns.md`

---

## 🎯 ONDA 3: Polish & Expansion (Semana 4-5) - 15-20 horas

### Task 3.1: Learning Objectives Em Todas Fases (12 horas)

Adicionar no INÍCIO de cada fase:

```markdown
## Learning Objectives

By the end of this phase, you will be able to:

1. ✅ [Objetivo 1]
2. ✅ [Objetivo 2]
... (5-8 objetivos por fase)

## Self-Assessment

Test your understanding:
- [ ] Pergunta 1
- [ ] Pergunta 2
... (5-8 perguntas)

## Project Assignment

Build: [Projeto prático específico]
Time estimate: X hours
Difficulty: Beginner/Intermediate/Advanced
```

---

### Task 3.2: Misconceptions Section (8 horas)

Adicionar em cada fase:

```markdown
## Common Misconceptions

❌ MISCONCEPTION: "..."
✅ REALITY: "..."
💡 WHY IT MATTERS: "..."

[5-8 misconceptions por fase]
```

---

## 📊 IMPLEMENTAÇÃO TIMELINE

```
SEMANA 1 (12h):
├─ Task 1.1: LEARNING-PATHS.md (4h)
├─ Task 1.2: Security Essentials (4h)
└─ Task 1.3: Cache Invalidation (4h)

SEMANA 2-3 (40h):
├─ Task 2.1: Testing Throughout (25h)
└─ Task 2.2: Security Anti-patterns (15h)

SEMANA 4-5 (20h):
├─ Task 3.1: Learning Objectives (12h)
└─ Task 3.2: Misconceptions (8h)

TOTAL: 72 horas
```

---

## ✅ CHECKLIST DE IMPLEMENTAÇÃO

### Onda 1: Quick Wins
- [ ] LEARNING-PATHS.md criado e linkado no índice
- [ ] Security Essentials adicionado à Fase 2
- [ ] Cache Invalidation Patterns adicionado à Fase 8
- [ ] Todos os links atualizados

### Onda 2: Core
- [ ] 017-Testing-Throughout.md expandido com exemplos
- [ ] 019-Security-Anti-patterns.md criado
- [ ] Exemplos de código verificados e testados
- [ ] Links atualizados em todas as fases

### Onda 3: Polish
- [ ] Learning Objectives em todas as 15 fases
- [ ] Misconceptions em todas as 15 fases
- [ ] Documento principal revisado e atualizado
- [ ] Índice atualizado com todos os novos links

---

## 🎯 SUCCESS METRICS

| Métrica | Antes | Depois | ROI |
|---------|-------|--------|-----|
| Score Geral | 4.25/5 | 4.8/5 | +13% |
| Cobertura | 95% | 100% | +5% |
| Qualidade | 4.3/5 | 4.7/5 | +9% |
| Pedagogia | 4.1/5 | 4.6/5 | +12% |
| Learning Time | 15+ weeks | 8-14 weeks | -40% |

---

**Próximas Etapas:** Começar com Onda 1 esta semana, Onda 2 semana que vem.

